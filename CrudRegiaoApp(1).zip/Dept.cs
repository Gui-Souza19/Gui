public class Dept
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;

    public int RegiaoId { get; set; }
    public Regiao? Regiao { get; set; }
}
