using System;
using System.Linq;
using Microsoft.EntityFrameworkCore; // ✅ necessário


class Program
{
    static void Main()
    {
        using var db = new AppDbContext();
        db.Database.EnsureCreated();

        int opcao;
        do
        {
            Console.WriteLine("\nCRUD REGIAO");
            Console.WriteLine("1. Listar");
            Console.WriteLine("2. Inserir");
            Console.WriteLine("3. Atualizar");
            Console.WriteLine("4. Deletar");
            Console.WriteLine("0. Sair");
            Console.Write("Opção: ");
            opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    foreach (var r in db.Regioes)
                        Console.WriteLine($"Id: {r.Id}, Nome: {r.Nome}");
                    break;
                case 2:
                    Console.Write("Nome: ");
                    var nome = Console.ReadLine();
                    db.Regioes.Add(new Regiao { Nome = nome });
                    db.SaveChanges();
                    Console.WriteLine("Inserido com sucesso!");
                    break;
                case 3:
                    Console.Write("Id a atualizar: ");
                    int idUp = int.Parse(Console.ReadLine());
                    var regiaoUp = db.Regioes.Find(idUp);
                    if (regiaoUp != null)
                    {
                        Console.Write("Novo nome: ");
                        regiaoUp.Nome = Console.ReadLine();
                        db.SaveChanges();
                        Console.WriteLine("Atualizado!");
                    }
                    else
                        Console.WriteLine("Região não encontrada.");
                    break;
                case 4:
                    Console.Write("Id a deletar: ");
                    int idDel = int.Parse(Console.ReadLine());
                    var regiaoDel = db.Regioes.Find(idDel);
                    if (regiaoDel != null)
                    {
                        db.Regioes.Remove(regiaoDel);
                        db.SaveChanges();
                        Console.WriteLine("Deletado!");
                    }
                    else
                        Console.WriteLine("Região não encontrada.");
                    break;
            }

        } while (opcao != 0);
    }
}
 