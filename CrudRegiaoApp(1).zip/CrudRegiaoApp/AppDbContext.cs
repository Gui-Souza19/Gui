using Microsoft.EntityFrameworkCore;

public class AppDbContext : DbContext
{
    public DbSet<Regiao> Regioes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite("Data Source=aluno.db");
}

